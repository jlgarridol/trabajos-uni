/**
 * Calcula los cuadrados de los elementos de una Matriz bidimensional
 * 
 * @author José Luis Garrido Labrador <JoseluCross>
 * @version 1.0
 */

public class Cuadrados {
	public static void main(String[] args) {
		final int M = 4, N = 4;// Dimensiones
		int[][] matriz;
		matriz = new int[M][N];
		// Damos valores a las Matrices
		inicializar(matriz);
		printArray(matriz);
		System.out.println("Cuadrados:");
		cuadrado(matriz);
		printArray(matriz);
	}

	/**
	 * @title printArray
	 * @description Imprime por pantalla una matriz int
	 * @author <JoseluCross>
	 * @version 1.0
	 * @param1 Mat - Array de 2 dimensión de int
	 */
	static public void printArray(int[][] mat) {
		for (int i = 0; i < mat.length; ++i) {
			for (int j = 0; j < mat[i].length; ++j) {
				System.out.print(mat[i][j] + "\t");
			}
			System.out.println();
		}
	}

	/**
	 * @title cuadrado
	 * @description hace el cuadrado de los elementos de una Matriz bidimecional
	 * @author <JoseluCross>
	 * @version 1.0
	 * @param1 mat - Array de 2 dimensión de int
	 */
	static public void cuadrado(int[][] mat) {
		for (int i = 0; i < mat.length; ++i) {
			for (int j = 0; j < mat[i].length; ++j) {
				mat[i][j] = mat[i][j] * mat[i][j];
			}
		}

	}

	/**
	 * @title inicializar
	 * @description rellena las matrices
	 * @author <JoseluCross>
	 * @version 1.0
	 * @param1 mat - Matriz a inicializar
	 */
	static public void inicializar(int[][] mat) {
		for (int i = 0, k = 1/* Valores para introducir */; i < mat.length; ++i) {
			for (int j = 0; j < mat[i].length; ++j, ++k) {
				mat[i][j] = k;
			}
		}

	}
}
