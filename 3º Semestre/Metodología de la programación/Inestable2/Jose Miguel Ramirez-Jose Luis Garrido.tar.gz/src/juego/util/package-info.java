/**
 * Paquetes con utilidades para el juego.
 * 
 * @author Raúl Marticorena
 * @since 1.0
 */
package juego.util;