/**
 * Paquete con el cli.
 * 
 * @author Jose Luis Garrido Labrador
 * @author José Miguel Ramírez Sans
 * @since 1.0
 * @version 2.0
 */
package juego.textui;